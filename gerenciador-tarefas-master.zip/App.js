import React, { useState, useEffect } from 'react';
import { SafeAreaView, FlatList, Text, ActivityIndicator, Alert, StyleSheet, View } from 'react-native';
import Formulario from './src/components/Formulario';
import ItemFilmes from './src/components/ItemFilmes';
import { getFilmes, postFilmes, putFilmes, deleteFilmes } from './src/services/filmesService';

export default function App() {
  const [filmes, setFilmes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editando, setEditando] = useState(false);
  const [idEdit, setIdEdit] = useState(null);

  const [titulo, setTitulo] = useState('');
  const [genero, setGenero] = useState('');
  const [ano, setAno] = useState('');

  useEffect(() => {
    carregar();
  }, []);

  const carregar = async () => {
    setLoading(true);
    try {
      const dados = await getFilmes();
      setFilmes(dados);
    } catch (e) {
      Alert.alert('Erro', 'Não carregou os Filmes');
    }
    setLoading(false);
  };

  const limpar = () => {
    setTitulo('');
    setGenero('');
    setAno('');
    setIdEdit(null);
  };

  const salvar = async () => {
    if (!titulo || !genero || !ano) {
      Alert.alert('Aviso', 'Preencha todos os campos');
      return;
    }

    const filmes = { titulo, genero, ano};

    try {
      if (editando) {
        await putFilmes(idEdit, filmes);
        Alert.alert('Sucesso', 'Filme atualizada');
      } else {
        await postFilmes(filmes);
        Alert.alert('Sucesso', 'Filme cadastrada');
      }
      limpar();
      carregar();
    } catch (e) {
      Alert.alert('Erro', 'Não foi possível salvar');
    }
  };

  const editar = (item) => {
    setTitulo(item.titulo);
    setGenero(item.genero);
    setAno(item.ano);
    setEditando(true);
    setIdEdit(item.id);
  };

  const excluir = async (id) => {
    console.log(id)
    try {
      await deleteFilmes(id);
      alert('Sucesso', 'Filme excluída');
      carregar();
    } catch (e) {
      alert('Erro', 'Não foi possível excluir');
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#007AFF" />
        <Text style={styles.loadingText}>Carregando Filmes...</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        data={filmes}
        keyExtractor={(item, index) => String(item.id ?? index)}
        ListHeaderComponent={
          <Formulario
            titulo={titulo}
            setTitulo={setTitulo}
            genero={genero}
            setGenero={setGenero}
            ano={ano}
            setAno={setAno}
            salvar={salvar}
            limpar={limpar}
            editando={editando}
          />
        }
        renderItem={({ item }) => (
          <ItemFilmes item={item} editar={editar} excluir={excluir} />
        )}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>Nenhuma Filme cadastrada</Text>
          </View>
        }
        contentContainerStyle={styles.listContent}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F4F6F9',
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F4F6F9',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#7F8C8D',
  },
  listContent: {
    paddingBottom: 24,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 30,
  },
  emptyText: {
    fontSize: 16,
    color: '#7F8C8D',
    fontWeight: '500',
  },
});