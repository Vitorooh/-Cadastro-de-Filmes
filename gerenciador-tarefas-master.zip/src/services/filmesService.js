const API = "https://6a309902a7f8866418d631fc.mockapi.io/gerenciador/tarefas";

export const getFilmes = () => fetch(API).then((r) => r.json());

export const postFilmes = (t) =>
  fetch(API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(t),
  }).then((r) => r.json());

export const putFilmes = (id, t) =>
  fetch(API + "/" + id, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(t),
  }).then((r) => r.json());

export const deleteFilmes = (id) =>
  fetch(API + "/" + id, { method: "DELETE" }).then((r) => r.json());