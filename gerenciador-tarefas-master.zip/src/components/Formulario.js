import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

export default function Formulario({
  titulo, setTitulo,
  genero, setGenero,
  ano, setAno,
  salvar,
  limpar,
  editando,
}) {
  return (
    <View style={styles.container}>
      <Text style={styles.tituloForm}>
        {editando ? 'EDITAR FILME' : 'NOVO FILME'}
      </Text>

      <TextInput
        style={styles.input}
        placeholder="Título do filme"
        value={titulo}
        onChangeText={setTitulo}
      />

      <TextInput
        style={styles.input}
        placeholder="Gênero"
        value={genero}
        onChangeText={setGenero}
      />

      <TextInput
        style={styles.input}
        placeholder="Ano"
        keyboardType="numeric"
        value={ano}
        onChangeText={setAno}
      />

      <TouchableOpacity
        style={[styles.btnSalvar, editando ? styles.btnEditar : styles.btnCadastrar]}
        onPress={salvar}
      >
        <Text style={styles.btnSalvarTexto}>
          {editando ? 'ATUALIZAR FILME' : 'CADASTRAR FILME'}
        </Text>
      </TouchableOpacity>

      {editando && (
        <TouchableOpacity style={styles.btnCancelar} onPress={limpar}>
          <Text style={styles.btnCancelarTexto}>CANCELAR EDIÇÃO</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
    margin: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  tituloForm: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    borderRadius: 8,
    padding: 12,
    marginBottom: 12,
    fontSize: 16,
    color: '#333',
  },
  btnSalvar: {
    padding: 14,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
  },
  btnCadastrar: {
    backgroundColor: '#007AFF',
  },
  btnEditar: {
    backgroundColor: '#E67E22',
  },
  btnSalvarTexto: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  btnCancelar: {
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
    borderWidth: 1,
    borderColor: '#BDC3C7',
    backgroundColor: '#fff',
  },
  btnCancelarTexto: {
    color: '#7F8C8D',
    fontWeight: 'bold',
    fontSize: 14,
  },
});