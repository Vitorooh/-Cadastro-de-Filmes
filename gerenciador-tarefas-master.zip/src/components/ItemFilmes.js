import React from 'react';
import { View, Text, TouchableOpacity, Alert, StyleSheet, Platform } from 'react-native';

export default function ItemFilmes({ item, editar, excluir }) {
  const confirmarExclusao = () => {
    if (Platform.OS === 'web') {
      if (window.confirm('Tem certeza que deseja excluir este filme?')) {
        excluir(item.id);
      }
    } else {
      Alert.alert('Excluir', 'Tem certeza que deseja excluir?', [
        { text: 'Não', style: 'cancel' },
        { text: 'Sim', onPress: () => excluir(item.id) },
      ]);
    }
  };

  return (
    <View style={styles.card}>
      <View style={styles.cardHeader}>
        <Text style={styles.cardTitulo}>{item.titulo}</Text>
        <View style={styles.badgeAno}>
          <Text style={styles.badgeAnoTexto}>{item.ano || 'N/A'}</Text>
        </View>
      </View>

      <Text style={styles.cardDescricao} numberOfLines={2}>
        {item.genero || 'Sem gênero informado'}
      </Text>

      <View style={styles.cardAcoes}>
        <TouchableOpacity style={[styles.btn, styles.btnEditar]} onPress={() => editar(item)}>
          <Text style={[styles.btnTexto, { color: '#E67E22' }]}>Editar</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.btn, styles.btnExcluir]} onPress={confirmarExclusao}>
          <Text style={[styles.btnTexto, { color: '#C0392B' }]}>Excluir</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    marginHorizontal: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.08,
    shadowRadius: 3,
    elevation: 2,
    borderLeftWidth: 5,
    borderLeftColor: '#007AFF',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardTitulo: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2C3E50',
    flex: 1,
    marginRight: 8,
  },
  badgeAno: {
    backgroundColor: '#007AFF',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  badgeAnoTexto: {
    fontSize: 12,
    color: '#fff',
    fontWeight: '700',
  },
  cardDescricao: {
    fontSize: 14,
    color: '#7F8C8D',
    marginBottom: 12,
    lineHeight: 20,
  },
  cardAcoes: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 8,
    borderTopWidth: 1,
    borderTopColor: '#ECF0F1',
    paddingTop: 10,
  },
  btn: {
    paddingVertical: 6,
    paddingHorizontal: 16,
    borderRadius: 6,
  },
  btnEditar: {
    backgroundColor: '#FFF2E6',
    borderWidth: 1,
    borderColor: '#FFE0CC',
  },
  btnExcluir: {
    backgroundColor: '#FCE4D6',
    borderWidth: 1,
    borderColor: '#F8CECC',
  },
  btnTexto: {
    fontSize: 13,
    fontWeight: '600',
  },
});